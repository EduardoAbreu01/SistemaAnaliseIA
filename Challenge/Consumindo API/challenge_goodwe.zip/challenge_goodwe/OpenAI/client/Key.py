global client
from openai import OpenAI

client = OpenAI(api_key="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")

