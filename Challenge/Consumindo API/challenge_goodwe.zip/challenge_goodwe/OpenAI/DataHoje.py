from datetime import date

def data():

    data_hoje = date.today()

    data_formatada = data_hoje.strftime("%Y-%m-%d")

    print(data_formatada)
    return data_formatada