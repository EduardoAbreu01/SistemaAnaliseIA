from OpenAI.client.Key import client
from playsound import playsound



def generate_speech(text,i):
  speech_file_path = f"analise{i}.mp3"

  with client.audio.speech.with_streaming_response.create(
      model="gpt-4o-mini-tts",
      voice="coral",
      input=text,
      instructions="Pronunciation: Clear, precise: Ensures clarity, especially with key details.",
  ) as response:
      response.stream_to_file(speech_file_path)
      path = "C:/PythonProject/challenge_goodwe/Assistant/" + speech_file_path
      playsound(path)
