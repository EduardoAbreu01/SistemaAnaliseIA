import requests
from OpenAI.AssitenteVoz import generate_speech
from Token.bearer import bearer

def apiRequest():
    url = 'http://127.0.0.1:8000/challenge/analisar'

    imagem = input("Insira o link da imagem: ")
    payload = {
        "url": f"{imagem}",
    }
    headers = {
        "Authorization": f"Bearer {bearer}"
    }
    response = requests.post(url, json=payload, headers=headers)

    response.raise_for_status()

    analises = response.json()
    print(type(analises))
    print(response)
    i = 1

    analise= analises["resultado"]["analise"]

    generate_speech(analise,i)






