import requests
from Token.bearer import bearer
from OpenAI.AssitenteVoz import generate_speech

from OpenAI.DataHoje import data


def recebeAnaliseData():
    dataUsuario = data()
    url = "http://127.0.0.1:8000/challenge/analises/data/" + dataUsuario

    headers = {
        "Authorization": f"Bearer {bearer}"
    }
    response = requests.get(url,headers=headers)
    response.raise_for_status()

    analises = response.json()
    analises = analises[0]

    objeto_saida = analises["saida"]
    analiseResp = objeto_saida["analise"]
    print(analiseResp)
    i = 1

    generate_speech(analiseResp, i)

