from Api.EnviaAnalise import apiRequest
from Api.RecebeAnalisePorData import recebeAnaliseData

#apiRequest()

recebeAnaliseData()


